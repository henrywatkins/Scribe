# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['scribe']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML', 'click>=8.1.3,<9.0.0', 'pathlib']

entry_points = \
{'console_scripts': ['scribe = scribe.cli:cli']}

setup_kwargs = {
    'name': 'scribe',
    'version': '0.1.0',
    'description': 'A helper for writing scientific papers',
    'long_description': '# Scribe\n\nA helper for writing scientific papers\n\n## Installation\n\nFrom within the repository, run\n\n## Usage\n\n```\nscribe create project_name.yml\n```\n\nWill create a project template YAML file and the command line interface will run through a set of questions to answer about your academic writing project. \n\n```\nscribe test project_name.yml\n```\n\nWill run through the answers given to the previous command and ask you to verify if there is enough info in the YAML to start converting it to a paper.\n\n## Features\n\n- to-markdown export feature\n- expand on skeleton feature\n- show sections feature\n- print whole paper to cli',
    'author': 'Henry Watkins',
    'author_email': 'h.watkins@ucl.ac.uk',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
